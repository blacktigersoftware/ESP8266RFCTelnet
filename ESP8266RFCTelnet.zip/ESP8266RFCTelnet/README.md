# ESP8266RFCTelnet
RFC Compliant extensible telnet library for the ESP8266
